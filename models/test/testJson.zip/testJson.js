/**
 * Created by Chance on 16/11/18.
 */

//json对象（Web传输
var json = {
    "caseId": "test0",
    "caseCaption": "test0",
    "caseLibId": "test0"
};
//json对象转为json形式字符串
var jsonStr = JSON.stringify(json);
//json字符串转为json对象
var json2 = JSON.parse(jsonStr);

//json对象和打印时会自动转为字符串
console.log(typeof json);
console.log(json);
console.log(typeof jsonStr);
console.log(jsonStr);
console.log(typeof json2);
console.log(json2);

//获取json字段的值
console.log(json.caseId);
//更改json字段的值
json.caseId = "new";
console.log(json.caseId);
//添加json字段
json.newId = "newId";
console.log(json);
//删除json字段
delete json.caseLibId;
console.log(json);